# Technical report source — 13 November 2026

This source produces the four-page report **Solar Filament Instance Segmentation with Native Detail and Auditable Model Selection**, by Francisco Angulo de Lafuente.

## Build

Use a complete TeX Live installation with pdfLaTeX and the `acmart`, `libertine`, `inconsolata`, `newtx`, `mathtools`, `subcaption`, `tabularx`, and `multirow` packages. From this directory, run:

```sh
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

References are contained in `main.tex`; BibTeX is not required. The source package includes the unmodified `acmart.cls` version 2.21 used for the verified build and its corresponding upstream source in `vendor/acmart/`. The compiled document uses the class's standard `sigconf` format, 9-point text, two columns and default page geometry. No geometry or font-size overrides are used. The official public Overleaf project was observed compiling with version 2.14; its documented format is unchanged here. Different TeX engines or package releases can change line breaks, so confirm the four-page limit after rebuilding. The supplied final PDF has already passed that check.

## Template provenance

The organizers' official template is:

https://www.overleaf.com/read/vjztpvrnbrdh#43fbbe

Its publicly rendered compilation log was inspected on 13 November 2026 and identified `acmart`, `sigconf`, and 9-point text. The visible outline contained Introduction, Methodology, Evaluation and Acknowledgment. The public editor did not expose every source line, and its download endpoint was restricted.

The template's `preamble.tex` was recovered from the attributed public copy at:

https://github.com/ameyypawar/filament-seg/blob/276db04e5be681bee2ad7e0ac2199b907a17a35f/reports/preamble.tex

Its accompanying commit explicitly states that the organizers' preamble and fixed text were preserved. The fixed subtitle, introduction opening and acknowledgment were cross-checked against another attributed public template copy:

https://github.com/regmi-sijan/solar-filament-segmentation-2026/blob/main/report/main.tex

Only shared template material was reused from these repositories. The method, measurements, figures and audit narrative belong to the Agnuxo1 entry and its recorded results. The report retains the fixed template sections and uses the public submission repository:

https://github.com/Agnuxo1/solar-filament-segmentation-2026

## Report provenance and limits

The two PNG illustrations were extracted losslessly from the participant's existing `TECHNICAL_REPORT_4P_20261112.pdf`. Their captions identify them as H6 training-partition diagnostics, not new H9b test results.

The reviewed evidence snapshot is public repository commit `83835e101bc7fa75479e680fc3585be27b530fc5`, together with the participant's original diagnostic summaries and code. Scientific results were not recomputed by this document revision. In particular:

- The official historical H9b public PQ remains 0.39, submission 58112557.
- P94 establishes exact reconstruction of the accepted CSV from frozen crops and original refiners.
- P102 has 14/15 exact RLE rows on its four-image upstream-replay pilot.
- No completed P103 180-image result, clean raw-JPEG end-to-end run, or organizer-form receipt is invented.

The report is an evidence snapshot through P104. Later notebook changes or newly completed evaluations require their own records and, when material, a report update.

## Upstream class license

The `acmart` class is maintained by Boris Veytsman and distributed under the LaTeX Project Public License, version 1.3 or later, as stated in its source. The unmodified class, source and upstream README are included to preserve attribution and rebuildability. Official distribution: https://ctan.org/pkg/acmart
